# Ad-hoc dependent components

This feature allows a developer to declare ad-hoc components for the sake of integrating ad-hoc built software components in the reverse dependency graph. 

## Stories

`TBD`

## Out of scope

`TBD`
