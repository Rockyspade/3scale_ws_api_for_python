package org.c;

public interface Something {}
