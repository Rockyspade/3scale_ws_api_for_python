package org.a;

import org.b2.Api;

public class Main implements Api {
   public static void main(String... args) {
      System.out.println("Answer is " + org.b1.Util.getAnswer());
   }
}
