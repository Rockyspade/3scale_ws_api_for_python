package org.b2;

public interface Api {
}
