package org.gradle.test

public @interface GroovyAnnotation {

}