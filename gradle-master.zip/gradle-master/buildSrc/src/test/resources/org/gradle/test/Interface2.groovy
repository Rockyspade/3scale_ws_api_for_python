package org.gradle.test

public interface Interface2 {

}